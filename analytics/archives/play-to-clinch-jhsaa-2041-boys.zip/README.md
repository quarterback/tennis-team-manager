# Play to Clinch research export

**Family:** JHSAA  
**Scope:** 2041 boys, all

Start with `manifest.json`. Shared entity tables are `programs`, `players`, `duals`, `lines`, and `line_players`; JHSAA-only standings, awards, and championship structures remain separate rather than being forced into a college schema.
