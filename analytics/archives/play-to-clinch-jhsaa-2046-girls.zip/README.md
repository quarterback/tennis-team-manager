# Play to Clinch research export

**Family:** JHSAA  
**Scope:** 2046 girls, all

Start with `manifest.json`. Shared entity tables are `programs`, `players`, `duals`, `lines`, and `line_players`; JHSAA-only standings, awards, team championships, and individual championship brackets remain separate rather than being forced into a college schema.
