# Jefferson expanded Google My Maps import

This package rebuilds the Jefferson map around the expanded 39-county footprint and the new 12-region geography.

## Fastest import

Import `jefferson_expanded_all_in_one.kmz` into a blank Google My Maps layer. It contains the state boundary, 12 region polygons, county footprints, all 343 existing gazetteer settlement points, and 10 eastern expansion county anchors.

## Better layer control

For separate My Maps layers, import these files in order:

1. `01_jefferson_state_regions.kml` — state outline + 12 colored regions
2. `02_jefferson_counties.kml` — all 39 county footprints
3. `03_jefferson_existing_settlements.kml` — 343 existing town points from the current gazetteer
4. `04_eastern_expansion_county_anchors.kml` — one interior marker for each newly added county

The region-to-county assignments used for this build are in `jefferson_region_county_crosswalk.csv` and `regions_map_v1.json`. The 10 eastern counties do not yet have new fictional Jefferson county names in the supplied canon, so the county layer identifies them by their underlying present-day county names rather than inventing canon.

The eastern anchor markers are explicitly county anchors, not invented settlements. Once eastern settlement coordinates are added to `settlements.json`, those can replace the anchor layer.
